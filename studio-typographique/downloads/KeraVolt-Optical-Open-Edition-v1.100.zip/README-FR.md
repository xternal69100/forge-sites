# KeraVolt Optical — Open Edition v1.100

Ce paquet public contient la famille technique **KeraVolt Optical**, style Regular, version 1.100.

## Fichiers

- `KeraVoltOptical-Regular.ttf` — format TrueType à contours `glyf` et GPOS ;
- `KeraVoltOptical-Regular.otf` — format OpenType à contours CFF natifs et GPOS ;
- `KeraVoltOptical-Regular.woff2` — format web WOFF2 ;
- `OFL.txt` — SIL Open Font License 1.1 ;
- `README-FR.md` — ce document.

## Licence

Copyright 2026 The Studio Typographique Forge Project Authors.

Les fichiers de fonte de ce paquet sont distribués sous **SIL Open Font License 1.1**, sans Reserved Font Name. Consultez `OFL.txt` avant redistribution ou modification. Le prix de cette Open Edition est CHF 0.

## Installation et web

Installez le TTF ou l’OTF avec le gestionnaire de fontes de votre système. Pour le web, servez le WOFF2 depuis votre propre domaine et déclarez-le avec `@font-face`.

## Portée des noms et des droits

« KeraVolt Optical » est un label d’édition et le nom technique conservé dans les binaires. Sa présence ne constitue pas une revendication de clearance de marque, de droit enregistré ou de titularité vérifiée. La licence de ce paquet porte sur les fichiers distribués. Elle ne constitue pas un avis juridique ni une garantie d’absence de droits de tiers.

## Couverture et limites

Une graisse statique, 168 points de code / 169 glyphes avec `.notdef`, couverture latine ciblée et paires GPOS de titrage. Pas d’italique ni d’axe variable ; aucune prétention à un Latin Extended complet.
