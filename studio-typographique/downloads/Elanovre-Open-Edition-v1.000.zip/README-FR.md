# Elanovre — Open Edition v1.000

Ce paquet public contient la famille technique **Elanovre**, style Regular, version 1.000.

## Fichiers

- `Elanovre-Regular.ttf` — format TrueType à contours `glyf` ;
- `Elanovre-Regular.otf` — format OpenType à contours CFF natifs ;
- `Elanovre-Regular.woff2` — format web WOFF2 ;
- `OFL.txt` — SIL Open Font License 1.1 ;
- `README-FR.md` — ce document.

## Licence

Copyright 2026 The Studio Typographique Forge Project Authors.

Les fichiers de fonte de ce paquet sont distribués sous **SIL Open Font License 1.1**, sans Reserved Font Name. Consultez `OFL.txt` avant redistribution ou modification. Le prix de cette Open Edition est CHF 0.

## Installation et web

Installez le TTF ou l’OTF avec le gestionnaire de fontes de votre système. Pour le web, servez le WOFF2 depuis votre propre domaine et déclarez-le avec `@font-face`.

## Portée des noms et des droits

« Elanovre » est un label d’édition et le nom technique conservé dans les binaires. Sa présence ne constitue pas une revendication de clearance de marque, de droit enregistré ou de titularité vérifiée. La licence de ce paquet porte sur les fichiers distribués. Elle ne constitue pas un avis juridique ni une garantie d’absence de droits de tiers.

## Couverture et limites

Une graisse statique, 142 points de code / 143 glyphes avec `.notdef`, français ciblé. Pas d’italique, d’axe variable, de kerning OpenType ni de hinting manuel. Usage display conseillé.
