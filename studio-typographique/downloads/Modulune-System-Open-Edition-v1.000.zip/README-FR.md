# Modulune System — Open Edition v1.000

Interface et display — recommandée de 20 à 32 px. Paquet gratuit sous SIL Open Font License 1.1, sans Reserved Font Name déclaré.

Le nom est un label d’édition provisoire. Aucune clearance de marque, disponibilité, exclusivité, droit enregistré ou titularité vérifiée n’est revendiquée. La licence de ce paquet porte sur les fichiers distribués.

Formats : TTF TrueType, OTF CFF natif et WOFF2. Une graisse Regular statique. Consultez OFL.txt pour le texte intégral.
